import UIKit

public struct Stack<T> {
    fileprivate var array = [T]()
    
    public var count: Int {
        return array.count
    }
    
    public var isEmpty: Bool {
        return array.isEmpty
    }
    
    public mutating func push(_ element: T) {
        array.append(element)
    }
    
    public mutating func pop() -> T? {
        return array.popLast()
    }
    
    public var top: T? {
        return array.last
    }
}


var stackOfNuber = Stack(array: [])


stackOfNuber.push("45")
stackOfNuber.push("1")
stackOfNuber.push("15")
stackOfNuber.push("20")
stackOfNuber.push("60")
print(stackOfNuber.array)

stackOfNuber.pop()
stackOfNuber.pop()
stackOfNuber.pop()
stackOfNuber.pop()
print(stackOfNuber.array)
