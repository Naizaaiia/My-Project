public struct Queue<T> {
    fileprivate var array = [T]()
    
    public var isEmpty: Bool {
        return array.isEmpty
    }
    
    public var count: Int {
        return array.count
    }
    
    public mutating func enqueue(_ element: T) {
        array.append(element)
    }
    
    public mutating func dequeue() -> T? {
        if isEmpty {
            return nil
        } else {
            return array.removeFirst()
        }
    }
    
    public var front: T? {
        return array.first
    }
}

var queue = Queue<Int>()
queue.enqueue(10)
queue.enqueue(1)
queue.enqueue(50)
queue.enqueue(20)
queue.enqueue(90)
print(queue)

queue.dequeue()
queue.dequeue()
queue.dequeue()
queue.dequeue()
print(queue)

